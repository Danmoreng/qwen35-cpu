# CPU comparison audit data

See https://github.com/Danmoreng/qwen35-cpu/blob/codex/cpu-standalone/docs/comparison-2026-09-06.md for methodology and limitations. Timed runs are speed-* only; quality profiles include logit I/O and must not be used as speed measurements. Raw float32 logits were removed after scoring. Original PowerShell results.csv files use German decimal commas; JSON profiles and the published summary CSVs use locale-independent numbers.

WikiText token-derived evaluation data: attribution to the WikiText dataset authors and Wikipedia contributors. The pinned dataset card lists CC BY-SA 3.0 and GFDL; those data licenses apply instead of the engine MIT license. Source: https://huggingface.co/datasets/Salesforce/wikitext/tree/b08601e04326c79dfdd32d625aee71d232d685c3
